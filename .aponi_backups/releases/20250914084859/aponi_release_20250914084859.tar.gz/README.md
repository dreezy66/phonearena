ADAAD / Aponi — Mega installer.
This repo was bootstrapped by mega_bigger_installer.sh.
Run `python3 phonearena_dashboard.py` to start the CLI.
