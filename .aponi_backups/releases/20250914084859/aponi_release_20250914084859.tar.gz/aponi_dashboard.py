import os
import time
import requests
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

try:
    from google.cloud import firestore
except ImportError:
    print("Warning: The 'google-cloud-firestore' library is not installed. Firestore functionality will be unavailable.")
    firestore = None

try:
    import google.generativeai as genai
except ImportError:
    print("Warning: The 'google-generativeai' library is not installed. LLM functionality will be unavailable.")
    genai = None

# --- Pythonic Data Structures (Advanced Enhancement) ---

@dataclass
class AgentStatus:
    """Represents a single agent's status."""
    id: str
    name: str
    parent: Optional[str]
    status: str

@dataclass
class LogEntry:
    """Represents a single log message."""
    timestamp: datetime
    message: str
    type: str

@dataclass
class PerformanceData:
    """Stores historical performance metrics for plotting."""
    labels: List[str]
    runs: List[int]
    errors: List[int]

@dataclass
class RemoteWorkerStatus:
    """Tracks the status of the remote worker."""
    online: bool
    tasksQueued: int
    lastPing: datetime

@dataclass
class AponiData:
    """The complete data model for the Aponi Dashboard."""
    activeAgents: int = 0
    successfulRuns: int = 0
    totalErrors: int = 0
    lineage: List[AgentStatus] = field(default_factory=list)
    remoteWorkerStatus: RemoteWorkerStatus = field(default_factory=RemoteWorkerStatus)
    agentLogs: List[LogEntry] = field(default_factory=list)
    performanceData: PerformanceData = field(default_factory=PerformanceData)

# --- Configuration & Core Logic ---

class AponiDashboard:
    """
    A low-resource, high-performance library for interacting with the Aponi
    autonomous agent dashboard data and its LLM-powered features.
    """
    def __init__(self, project_id: str, api_key: str):
        """
        Initializes the AponiDashboard client.
        
        Args:
            project_id (str): Your Google Cloud project ID.
            api_key (str): Your Gemini API key.
        """
        if not all([firestore, genai]):
            raise ImportError("Required libraries are not installed. Please run: pip install google-cloud-firestore google-generativeai")

        self.db = firestore.Client(project=project_id)
        genai.configure(api_key=api_key)
        self.generation_model = genai.GenerativeModel('gemini-2.5-flash-preview-05-20')

        self.collection_path = "artifacts/default-app-id/public/data/aponi_dashboard_metrics"
        self.doc_ref = self.db.collection(self.collection_path).document('metrics')
        
        # Simple in-memory cache to reduce frequent Firestore reads.
        self._data_cache = None
        self._cache_time = 0
        self._cache_ttl = 30  # seconds

    def _get_system_prompt(self, role: str) -> str:
        """Returns the appropriate system prompt for a given role."""
        prompts = {
            "assistant": "You are an AI assistant for an autonomous agent dashboard. Your role is to provide concise, helpful, and creative insights about agents, system performance, or potential issues. You can suggest new agents, provide debugging tips for a given error message, or summarize system data. Keep your responses friendly and professional.",
            "report_writer": "You are a professional technical report writer. Your task is to generate a concise, well-formatted Markdown report summarizing the provided autonomous agent dashboard data. The report should include key performance indicators (KPIs), a summary of agent statuses, and a brief overview of recent log activity. Use markdown headings and lists for clear structure. Do not invent any data.",
            "live_logger": "You are a live system logger for an AI agent dashboard. Generate a single, concise, and realistic log entry. The entry should be one of the following types: system event, agent action, or a minor error. Format it as a simple string, for example: 'Agent Alpha started task 345' or 'Remote worker established connection'.",
        }
        return prompts.get(role, "")

    def _update_cache(self, data: Dict[str, Any]):
        """Updates the in-memory cache with new data and timestamp."""
        self._data_cache = data
        self._cache_time = time.time()

    def get_dashboard_data(self, use_cache: bool = True) -> Optional[AponiData]:
        """
        Fetches the latest dashboard data from Firestore.
        Uses a short-lived cache to prevent excessive reads.
        
        Returns:
            AponiData: An object containing the dashboard metrics.
        """
        if use_cache and (time.time() - self._cache_time) < self._cache_ttl and self._data_cache:
            print("Using cached data.")
            return self._data_cache
            
        try:
            doc_snapshot = self.doc_ref.get()
            if doc_snapshot.exists:
                data = doc_snapshot.to_dict()
                
                # Convert timestamps to datetime objects
                if 'remoteWorkerStatus' in data and 'lastPing' in data['remoteWorkerStatus']:
                    data['remoteWorkerStatus']['lastPing'] = datetime.fromisoformat(data['remoteWorkerStatus']['lastPing'].replace('Z', '+00:00'))
                if 'agentLogs' in data:
                    for log in data['agentLogs']:
                        log['timestamp'] = datetime.fromisoformat(log['timestamp'].replace('Z', '+00:00'))
                        
                aponi_data = AponiData(**data)
                self._update_cache(aponi_data)
                print("Fetched new data from Firestore.")
                return aponi_data
            else:
                print("No data found. Setting up mock data...")
                self._setup_mock_data()
                return self.get_dashboard_data(use_cache=False)
        except Exception as e:
            print(f"Error fetching data from Firestore: {e}")
            return None

    def _setup_mock_data(self):
        """Creates initial mock data in Firestore."""
        initial_data = {
            "activeAgents": 12,
            "successfulRuns": 85,
            "totalErrors": 5,
            "lineage": [
                {"id": "agent_alpha", "name": "Alpha Agent", "parent": None, "status": "Running"},
                {"id": "agent_beta", "name": "Beta Agent", "parent": "agent_alpha", "status": "Sleeping"},
                {"id": "agent_gamma", "name": "Gamma Agent", "parent": "agent_alpha", "status": "Error"}
            ],
            "remoteWorkerStatus": {
                "online": True,
                "tasksQueued": 3,
                "lastPing": datetime.now(timezone.utc).isoformat()
            },
            "agentLogs": [
                {"timestamp": datetime.now(timezone.utc).isoformat(), "message": "System started.", "type": "info"},
                {"timestamp": datetime.now(timezone.utc).isoformat(), "message": "Agent Alpha initialized.", "type": "info"},
                {"timestamp": datetime.now(timezone.utc).isoformat(), "message": "Agent Gamma encountered a timeout error.", "type": "error"}
            ],
            "performanceData": {
                "labels": ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                "runs": [30, 45, 60, 55, 75, 85],
                "errors": [2, 1, 3, 2, 1, 0]
            }
        }
        self.doc_ref.set(initial_data)

    def generate_insight(self, user_prompt: str) -> str:
        """Generates an insightful response using the Gemini API."""
        if not genai: return "LLM functionality is not available."
        prompt = f"Data overview:\n{asdict(self.get_dashboard_data())}\n\nUser request: {user_prompt}"
        response = self.generation_model.generate_content(
            prompt,
            system_instruction=self._get_system_prompt("assistant")
        )
        return response.text if response else "Failed to generate insight."

    def generate_report(self) -> str:
        """Generates a professional report in Markdown based on current data."""
        if not genai: return "LLM functionality is not available."
        data = self.get_dashboard_data()
        if not data:
            return "Unable to retrieve dashboard data for report generation."

        prompt = f"""Generate a report based on the following data:

KPIs:
- Active Agents: {data.activeAgents}
- Successful Runs: {data.successfulRuns}
- Total Errors: {data.totalErrors}

Agent Statuses:
{data.lineage}

Recent Logs:
{data.agentLogs[-5:]}
"""
        response = self.generation_model.generate_content(
            prompt,
            system_instruction=self._get_system_prompt("report_writer")
        )
        return response.text if response else "Failed to generate report."

    def generate_log_entry(self) -> Optional[LogEntry]:
        """Generates a new, realistic log entry and adds it to Firestore."""
        if not genai:
            print("LLM functionality is not available.")
            return None
        
        response = self.generation_model.generate_content(
            "Generate a log entry.",
            system_instruction=self._get_system_prompt("live_logger")
        )
        message = response.text
        log_type = "info"
        if "error" in message.lower() or "failure" in message.lower() or "timeout" in message.lower():
            log_type = "error"
        
        new_log = LogEntry(timestamp=datetime.now(timezone.utc), message=message, type=log_type)
        print(f"Generated new log: {new_log.message}")
        
        try:
            # Atomic update to append a new log entry
            self.doc_ref.update({"agentLogs": firestore.ArrayUnion([
                {"timestamp": new_log.timestamp.isoformat(), "message": new_log.message, "type": new_log.type}
            ])})
            return new_log
        except Exception as e:
            print(f"Error adding log to Firestore: {e}")
            return None

# --- Example Usage (Command-Line Interface) ---

if __name__ == "__main__":
    import argparse
    
    # Environment variables for secure configuration
    PROJECT_ID = os.environ.get("GCP_PROJECT_ID")
    API_KEY = os.environ.get("GEMINI_API_KEY")

    if not all([PROJECT_ID, API_KEY]):
        print("Please set the GCP_PROJECT_ID and GEMINI_API_KEY environment variables.")
        exit(1)

    aponi = AponiDashboard(project_id=PROJECT_ID, api_key=API_KEY)

    parser = argparse.ArgumentParser(description="Aponi Dashboard Command-Line Tool.")
    parser.add_argument("command", choices=["data", "insight", "report", "log"], help="The command to run.")
    parser.add_argument("--prompt", type=str, help="Prompt for the 'insight' command.")
    args = parser.parse_args()

    print("✨ Connecting to Aponi...")

    if args.command == "data":
        data = aponi.get_dashboard_data()
        if data:
            print("--- Current Aponi Dashboard Data ---")
            print(f"Active Agents: {data.activeAgents}")
            print(f"Successful Runs: {data.successfulRuns}")
            print(f"Total Errors: {data.totalErrors}")
            print("\nAgent Lineage:")
            for agent in data.lineage:
                print(f"  - {agent.name}: {agent.status}")
            print("\nRecent Logs:")
            for log in data.agentLogs:
                print(f"  - [{log.type}] {log.message}")

    elif args.command == "insight":
        if not args.prompt:
            print("Error: The 'insight' command requires a '--prompt' argument.")
            exit(1)
        print(f"--- Generating insight for: '{args.prompt}' ---")
        insight = aponi.generate_insight(args.prompt)
        print("\n", insight, "\n")
        
    elif args.command == "report":
        print("--- Generating Performance Report ---")
        report = aponi.generate_report()
        print("\n", report, "\n")
        
    elif args.command == "log":
        print("--- Generating a new log entry ---")
        new_log = aponi.generate_log_entry()
        if new_log:
            print("New entry added to live log.")