#!/usr/bin/env python3
from core.phonearena_core import run_ecosystem_cycle
def run():
    ok,msg = run_ecosystem_cycle()
    return ok,msg
