def add(a,b): return a+b

def run():
    print("example_app running")

if __name__ == "__main__":
    run()
