#!/data/data/ru.iiec.pydroid3/files/usr/bin/bash
# aponi_publish.sh — build + serve Aponi release (Termux / Pydroid friendly)
set -euo pipefail
IFS=$'\n\t'

ROOT="${1:-.}"
PORT="${2:-8000}"
MODE="${3:-fg}"    # fg = foreground, bg = background
FORMAT="${4:-both}" # tar | zip | both
KEEP="${5:-12}"     # keep last N releases

ROOT="$(cd "$ROOT" && pwd -P)"
mkdir -p "$ROOT/.aponi_backups/releases"
mkdir -p "$ROOT/.aponi_backups"

log() { printf '>>> %s\n' "$*"; }

# cleanup helper for temp files
TMPFILES=()
cleanup() {
  for t in "${TMPFILES[@]:-}"; do
    [ -e "$t" ] && rm -f "$t"
  done
}
trap cleanup EXIT

TS="$(date +%Y%m%d%H%M%S)"
REL_DIR=".aponi_backups/releases/$TS"
RELEASE_DIR="$ROOT/$REL_DIR"
mkdir -p "$RELEASE_DIR"

log "Building release: $RELEASE_DIR (format=$FORMAT)"

# regenerate tree.json if script exists
if [ -x "$ROOT/tree_json.py" ] || [ -f "$ROOT/tree_json.py" ]; then
  log "Regenerating tree.json (if supported)"
  python3 "$ROOT/tree_json.py" --json . > "$ROOT/tree.json" 2>/dev/null || log "tree_json.py failed (continuing)"
fi

# create tar.gz
if [ "$FORMAT" = "tar" ] || [ "$FORMAT" = "both" ]; then
  TAR_OUT="$RELEASE_DIR/aponi_release_${TS}.tar.gz"
  log "Creating tar.gz -> $(basename "$TAR_OUT")"
  (cd "$ROOT" && tar -czf "$TAR_OUT" \
      --exclude='.aponi_backups' \
      --exclude='.git' \
      --exclude='node_modules' \
      --exclude='__pycache__' \
      --exclude='*.pyc' \
      --exclude='*.log' \
      --exclude='.DS_Store' .)
  # symlink if possible, else copy (Android shared storage usually forbids symlinks)
  if ! ln -sfn "$TAR_OUT" "$ROOT/.aponi_backups/latest.tar.gz" 2>/dev/null; then
    cp -f "$TAR_OUT" "$ROOT/.aponi_backups/latest.tar.gz"
  fi
fi

# create zip (zip tool preferred; fallback to python)
if [ "$FORMAT" = "zip" ] || [ "$FORMAT" = "both" ]; then
  ZIP_OUT="$RELEASE_DIR/aponi_release_${TS}.zip"
  log "Creating zip -> $(basename "$ZIP_OUT")"
  if command -v zip >/dev/null 2>&1; then
    (cd "$ROOT" && zip -q -r "$ZIP_OUT" . \
       -x ".aponi_backups/*" ".git/*" "node_modules/*" "__pycache__/*" "*.pyc" "*.log" ".DS_Store")
  else
    # python fallback
    python3 - <<PY "$ROOT" "$ZIP_OUT"
import os,sys,zipfile
root,out=sys.argv[1:]
excl={'.aponi_backups','.git','node_modules','__pycache__'}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for dp,ds,fs in os.walk(root):
        parts = dp.split(os.sep)
        if any(p in excl for p in parts): continue
        for f in fs:
            if f.endswith(('.pyc','.log')) or f=='.DS_Store': continue
            full = os.path.join(dp,f)
            z.write(full, os.path.relpath(full, root))
print("zip done")
PY
  fi
  if ! ln -sfn "$ZIP_OUT" "$ROOT/.aponi_backups/latest.zip" 2>/dev/null; then
    cp -f "$ZIP_OUT" "$ROOT/.aponi_backups/latest.zip"
  fi
fi

# compute metadata (sha256 + sizes) using python for portability
METADATA_FILE="$RELEASE_DIR/metadata.json"
ARTIFACTS=()
[ -f "$TAR_OUT" ] && ARTIFACTS+=("$TAR_OUT")
[ -f "$ZIP_OUT" ] && ARTIFACTS+=("$ZIP_OUT")

python3 - <<PY "$TS" "$ROOT" "$METADATA_FILE" "${ARTIFACTS[@]:-}"
import sys,os,json,hashlib
ts,root,meta = sys.argv[1:4]
files = sys.argv[4:]
meta_obj = {"timestamp": ts, "root": root, "artifacts": []}
total = 0
for f in files:
    try:
        s = os.path.getsize(f)
        h = hashlib.sha256()
        with open(f,'rb') as fh:
            for chunk in iter(lambda: fh.read(65536), b''):
                h.update(chunk)
        meta_obj["artifacts"].append({"file": os.path.basename(f), "size": s, "sha256": h.hexdigest()})
        total += s
    except Exception as e:
        meta_obj["artifacts"].append({"file": os.path.basename(f), "error": str(e)})
meta_obj["total_archive_size_bytes"] = total
meta_obj["files_count"] = sum(1 for _ in os.walk(root) if True)  # rough count placeholder
with open(meta, "w") as fh:
    json.dump(meta_obj, fh, indent=2)
print("metadata written")
PY

# prune older releases (keep newest KEEP)
if [ "${KEEP:-0}" -gt 0 ]; then
  PARENT="$ROOT/.aponi_backups/releases"
  if [ -d "$PARENT" ]; then
    # list numeric timestamp dirs, drop the newest KEEP
    TO_REMOVE=$(ls -1d "$PARENT"/*/ 2>/dev/null | sed 's#/$##' | sed 's#.*/##' | sort | head -n -"${KEEP}" || true)
    if [ -n "$TO_REMOVE" ]; then
      log "Pruning old releases..."
      for d in $TO_REMOVE; do
        log " - removing $d"
        rm -rf "$PARENT/$d"
      done
    fi
  fi
fi

# choose artifact to serve (prefer tar then zip)
TARGET=""
if [ -f "$ROOT/.aponi_backups/latest.tar.gz" ]; then
  TARGET="$ROOT/.aponi_backups/latest.tar.gz"
elif [ -f "$ROOT/.aponi_backups/latest.zip" ]; then
  TARGET="$ROOT/.aponi_backups/latest.zip"
fi

if [ -z "$TARGET" ] || [ ! -f "$TARGET" ]; then
  log "ERROR: no artifact to serve (expected latest.tar.gz or latest.zip)"
  exit 1
fi

SERVE_DIR=$(dirname "$TARGET")
BASENAME=$(basename "$TARGET")
URL="http://127.0.0.1:${PORT}/${BASENAME}"

log "Serving: $TARGET"
log "URL: $URL"

# print QR code if qrcode_terminal available
python3 - <<PY || true
try:
    import qrcode_terminal, sys
    qrcode_terminal.draw(sys.argv[1])
except Exception:
    print("(QR skipped — install qrcode_terminal to show ASCII QR)")
PY "$URL"

# start HTTP server
cd "$SERVE_DIR"
if [ "$MODE" = "bg" ]; then
  nohup python3 -m http.server "$PORT" --bind 0.0.0.0 &> "$ROOT/aponi_share.log" &
  log "Server started in background (log: $ROOT/aponi_share.log)"
  log "Download: $URL"
else
  log "Foreground mode — Ctrl-C to stop"
  python3 -m http.server "$PORT" --bind 0.0.0.0
fi