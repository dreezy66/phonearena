#!/usr/bin/env python3
from core.phonearena_core import run_beast_mode_cycle
def run():
    ok,msg = run_beast_mode_cycle()
    return ok,msg
