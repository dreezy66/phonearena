#!/usr/bin/env python3
from core.phonearena_core import try_pack_project
def run(path):
    return try_pack_project(path)
