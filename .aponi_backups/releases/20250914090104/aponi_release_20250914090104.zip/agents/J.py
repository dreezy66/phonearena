# ADAAD agent fallback template
'''
Simple generated agent
'''

class Agent:
    def __init__(self):
        pass

    def run(self):
        return 'Hello from J'
