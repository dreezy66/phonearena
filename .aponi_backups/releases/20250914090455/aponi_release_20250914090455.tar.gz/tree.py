#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ADAAD Tree Dashboard — full-featured explorer + agent tagging + HTML dashboard
Drop into: /storage/emulated/0/ADAAD/adaad_tree_dashboard.py
Run: python adaad_tree_dashboard.py --help
"""

from __future__ import annotations

import argparse
import fnmatch
import html
import json
import os
import shutil
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------
# Brand Colors & Icons (ADAAD style)
# ---------------------------
class C:
    BOLD = "\033[1m"
    END = "\033[0m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    MAG = "\033[35m"

ICONS = {
    "dir": "📂",
    "file": "📄",
    "beast": "🐉",
    "improved": "⚡",
    "generated": "✨",
    "quarantine": "🛑",
    "needs_repair": "🧨",
    "ok": "✅",
    "warn": "⚠️",
}

# ---------------------------
# Default excludes & runtime whitelist
# ---------------------------
DEFAULT_EXCLUDE_DIR_PATTERNS = [
    "*.backup*", ".backups", "patch_backups", "__pycache__", ".pytest_cache",
    "$recycle.bin$", ".$recycle_bin$", ".git", ".hg", ".svn", "libs", "prefix",
    "lib", "adaad_venv", "backups", "archive", "tmp", "node_modules", "venv"
]

DEFAULT_EXCLUDE_FILE_PATTERNS = [
    "*backup*", "*.bak*", "*.tmp", "*.swp", "*.log"
]

# runtime folders which matter to run ADAAD
RUNTIME_WHITELIST = {
    "core",
    "agents",
    "generated_agents",
    "plugins",
    "bin",
    "scripts",
    "remote_worker",
    "marketing",
    "main.py",
    "run_adaad.sh",
    "adaad_env.sh",
    "adaad_logs",
    "quarantine",
    "recovered_sources",
    "marketplace_data",
    "data",
}

# ---------------------------
# Data classes
# ---------------------------
@dataclass
class NodeInfo:
    path: Path
    name: str
    is_dir: bool
    size: int = 0
    children: List["NodeInfo"] = None
    tag: Optional[str] = None
    health: Optional[str] = None  # ok, warn, broken, unknown

    def to_dict(self) -> Dict:
        return {
            "path": str(self.path),
            "name": self.name,
            "is_dir": self.is_dir,
            "size": self.size,
            "tag": self.tag,
            "health": self.health,
            "children": [c.to_dict() for c in (self.children or [])],
        }

# ---------------------------
# Helpers
# ---------------------------
def is_excluded_dir(name: str, patterns: List[str]) -> bool:
    name = name.lower()
    return any(fnmatch.fnmatch(name, p.lower()) for p in patterns)

def is_excluded_file(name: str, patterns: List[str]) -> bool:
    name = name.lower()
    return any(fnmatch.fnmatch(name, p.lower()) for p in patterns)

def path_matches_whitelist(path: Path, root: Path) -> bool:
    try:
        rel = path.relative_to(root)
    except Exception:
        return False
    rel_str = str(rel).replace(os.sep, "/")
    for w in RUNTIME_WHITELIST:
        if rel_str == w or rel_str.startswith(w + "/") or (w.endswith(".py") and rel_str.endswith(w)):
            return True
    return False

def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024.0
    return f"{n:.1f}TB"

# Static (safe) agent analysis — no execution
AGENT_FILENAME_TAGS = [
    ("beast", ["beastv", "beast"]),
    ("improved", ["improved", "_improved_"]),
    ("needs_repair", ["needs_repair", "needs-repair", "needsrepair"]),
    ("generated", ["agent_", "generated_agents", "agent_initial_seed", "good_agent"])
]

def detect_agent_tag(path: Path) -> Optional[str]:
    """Detect tag from filename or path"""
    name = path.name.lower()
    if "quarantine" in str(path).lower() or path.suffix and ".quarantine" in name:
        return "quarantine"
    for tag, tokens in AGENT_FILENAME_TAGS:
        for t in tokens:
            if t in name:
                return tag
    return None

def analyze_agent_file(path: Path) -> Tuple[Optional[str], Optional[str]]:
    """
    Perform safe static checks:
      - syntax via compile()
      - presence of obvious entrypoints: 'def run', 'class Agent', 'agent = Agent'
    Returns (tag_hint, health) where health in {'ok','warn','broken','unknown'}
    """
    try:
        txt = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None, "unknown"
    tag = detect_agent_tag(path)
    # quick syntax check
    try:
        compile(txt, str(path), "exec")
    except SyntaxError as se:
        return tag, "broken"
    except Exception:
        return tag, "warn"
    # entrypoint heuristics
    lowered = txt.lower()
    entrypoints = any(k in lowered for k in ("def run", "class agent", "class Agent".lower(), "agent ="))
    if entrypoints:
        return tag, "ok"
    # no clear entrypoint -> warn
    return tag, "warn"

# ---------------------------
# Tree builder (with tagging)
# ---------------------------
def build_tree(root: Path, max_depth: Optional[int], exclude_dirs: List[str],
               exclude_files: List[str], focus: str) -> Tuple[NodeInfo, Dict[str,int]]:
    """
    Build NodeInfo tree rooted at root. Returns (root_node, summary_counts)
    summary_counts: {"dirs": int, "files": int, "agents": int}
    """
    counts = {"dirs": 0, "files": 0, "agents": 0}

    def _build(p: Path, depth: int) -> NodeInfo:
        node = NodeInfo(path=p, name=p.name or str(p), is_dir=p.is_dir(), children=[])
        if max_depth is not None and depth > max_depth:
            return node
        try:
            it = sorted(list(p.iterdir()), key=lambda x: (not x.is_dir(), x.name.lower()))
        except PermissionError:
            return node
        for child in it:
            name = child.name
            if child.is_dir() and is_excluded_dir(name, exclude_dirs):
                continue
            if child.is_file() and is_excluded_file(name, exclude_files):
                continue
            # focus filter: runtime
            if focus == "runtime":
                if not (path_matches_whitelist(child, root) or path_matches_whitelist(p, root)):
                    # if neither child nor parent path is whitelisted, skip
                    continue
            if child.is_dir():
                counts["dirs"] += 1
                child_node = _build(child, depth + 1)
                node.children.append(child_node)
            else:
                counts["files"] += 1
                size = 0
                try:
                    size = child.stat().st_size
                except Exception:
                    pass
                child_node = NodeInfo(path=child, name=child.name, is_dir=False, size=size, children=[])
                # agent detection: only for .py files in agents or generated_agents
                if child.suffix == ".py" and ("agents" in str(child.parent).split(os.sep) or "generated_agents" in str(child.parent).split(os.sep)):
                    counts["agents"] += 1
                    tag, health = analyze_agent_file(child)
                    child_node.tag = tag
                    child_node.health = health
                node.children.append(child_node)
        return node

    root_node = _build(root, 0)
    return root_node, counts

# ---------------------------
# Console printer (pretty)
# ---------------------------
def print_tree(node: NodeInfo, prefix: str = "") -> None:
    if node.is_dir:
        print(prefix + ICONS["dir"] + " " + node.name + "/")
        for idx, c in enumerate(node.children):
            connector = "└── " if idx == len(node.children) - 1 else "├── "
            if c.is_dir:
                extension = "    " if idx == len(node.children) - 1 else "│   "
                print(prefix + connector, end="")
                print_tree(c, prefix + extension)
            else:
                tag = f" [{c.tag}]" if c.tag else ""
                health_mark = ICONS["ok"] if c.health == "ok" else ICONS["warn"] if c.health == "warn" else ICONS["needs_repair"] if c.health == "broken" else ""
                print(prefix + connector + ICONS["file"] + " " + c.name + tag + " " + health_mark)

# ---------------------------
# HTML Export (brand style)
# ---------------------------
BRAND_CSS = """
:root{
  --bg:#0b1020; --panel:#0f1724; --accent:#00e6a6; --muted:#7aa2c7; --danger:#ff5c7c; --glass: rgba(255,255,255,0.04);
  --mono: 'DejaVu Sans Mono', 'Courier New', monospace;
}
html,body{height:100%;background:linear-gradient(180deg,#071228 0%, #071020 100%);color:#d8eef3;font-family:Inter,Segoe UI,Helvetica,Arial,sans-serif;margin:0}
.header{padding:18px;display:flex;align-items:center;gap:16px}
.logo{width:64px;height:64px;border-radius:10px;background:linear-gradient(135deg,#00e6a6,#00d0ff);display:flex;align-items:center;justify-content:center;font-weight:700;color:#021;box-shadow:0 6px 18px rgba(0,0,0,0.5)}
.container{padding:16px}
.panel{background:var(--panel);border-radius:10px;padding:12px;box-shadow: 0 6px 30px rgba(0,0,0,0.6);margin-bottom:12px}
.tree pre{font-family:var(--mono);font-size:13px;white-space:pre-wrap}
.badge{padding:3px 8px;border-radius:999px;background:var(--glass);color:var(--muted);font-size:12px;margin-left:8px}
.tag-beast{color:#ffd166}
.tag-improved{color:#ffb4a2}
.tag-generated{color:#bde0fe}
.tag-quarantine{color:var(--danger)}
.health-ok{color:var(--accent)}
.health-warn{color:#ffb86b}
.search{margin-left:auto}
.controls{display:flex;gap:8px;align-items:center}
.small{font-size:12px;color:var(--muted)}
.folder{cursor:pointer}
.hidden{display:none}
.summary{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
.card{background:linear-gradient(90deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:8px;border-radius:8px}
"""

HTML_TEMPLATE = """<!doctype html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title>ADAAD Tree Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1"/>
    <style>{css}</style>
  </head>
  <body>
    <div class="header">
      <div class="logo">ADAAD</div>
      <div>
        <div style="font-weight:700;font-size:18px">ADAAD Project Explorer</div>
        <div class="small">Focused runtime map + agent health</div>
      </div>
      <div class="search">
        <input id="filter" placeholder="filter files / tags (beast, improved, quarantine)"/>
      </div>
    </div>
    <div class="container">
      <div class="panel summary" id="summary"></div>
      <div class="panel tree" id="tree">${TREE_HTML}</div>
    </div>
    <script>
      // collapse/expand
      document.addEventListener('click', function(ev){
        if(ev.target.classList.contains('folder')){
          var node = ev.target.nextElementSibling;
          if(node) node.classList.toggle('hidden');
        }
      });
      // filter
      document.getElementById('filter').addEventListener('input', function(){
        var q = this.value.trim().toLowerCase();
        document.querySelectorAll('[data-name]').forEach(function(el){
          var name = el.getAttribute('data-name').toLowerCase();
          var tags = el.getAttribute('data-tags') || '';
          var ok = !q || name.includes(q) || tags.includes(q);
          el.style.display = ok ? '' : 'none';
        });
      });
      // populate summary counts
      (function(){
        try {
          var s = JSON.parse(document.getElementById('tree').getAttribute('data-summary') || '{}');
          var container = document.getElementById('summary');
          container.innerHTML = '';
          var k = ['dirs','files','agents'];
          k.forEach(function(key){
            var card = document.createElement('div'); card.className='card';
            card.innerHTML = '<div style="font-weight:700">'+(s[key]||0)+'</div><div class="small">'+key+'</div>';
            container.appendChild(card);
          });
        } catch(e){}
      })();
    </script>
  </body>
</html>
"""

def node_to_html(node: NodeInfo, root: Path) -> str:
    """
    Convert a NodeInfo tree into nested HTML.
    Files are <div data-name=... data-tags=...> elements for search.
    """
    def esc(s): return html.escape(s)
    lines: List[str] = []
    def _render(n: NodeInfo, indent: int = 0):
        spacer = "&nbsp;" * (indent * 4)
        if n.is_dir:
            # clickable span with class folder
            lines.append(f'{spacer}<div><span class="folder"><strong>{esc(n.name)}/</strong></span><div>')
            lines.append(f'<div style="margin-left:12px">')
            for c in (n.children or []):
                _render(c, indent + 1)
            lines.append('</div></div></div>')
        else:
            tags = []
            if n.tag:
                tags.append(n.tag)
            health = n.health or ""
            tag_html = ""
            if n.tag == "beast":
                tag_html = f'<span class="badge tag-beast">🐉 beast</span>'
            elif n.tag == "improved":
                tag_html = f'<span class="badge tag-improved">⚡ improved</span>'
            elif n.tag == "generated":
                tag_html = f'<span class="badge tag-generated">✨ generated</span>'
            elif n.tag == "quarantine":
                tag_html = f'<span class="badge tag-quarantine">🛑 quarantine</span>'
            elif n.tag == "needs_repair":
                tag_html = f'<span class="badge tag-quarantine">🧨 needs_repair</span>'
            health_html = ''
            if health == "ok":
                health_html = f'<span class="badge health-ok">✅ OK</span>'
            elif health == "warn":
                health_html = f'<span class="badge health-warn">⚠️ WARN</span>'
            elif health == "broken":
                health_html = f'<span class="badge tag-quarantine">🧨 BROKEN</span>'
            size = f" <span class='small'>{human_size(n.size)}</span>" if n.size else ""
            data_tags = " ".join(tags + ([health] if health else []))
            lines.append(f'{spacer}<div data-name="{esc(n.name)}" data-tags="{esc(data_tags)}">{ICONS["file"]} {esc(n.name)} {tag_html} {health_html}{size}</div>')
    _render(node, 0)
    return "\n".join(lines)

# ---------------------------
# Cleanup / optimizer (optional)
# ---------------------------
def find_cleanup_targets(root: Path) -> Tuple[List[Path], List[Path], List[Path]]:
    pycache_dirs: List[Path] = []
    pyc_files: List[Path] = []
    empty_dirs: List[Path] = []
    for p in root.rglob("*"):
        if p.is_dir() and p.name == "__pycache__":
            pycache_dirs.append(p)
        if p.is_file() and p.suffix == ".pyc":
            pyc_files.append(p)
    # find empty dirs
    for d in sorted({p.parent for p in pycache_dirs} | {p.parent for p in pyc_files}):
        try:
            if d.exists() and d.is_dir() and not any(True for _ in d.iterdir()):
                empty_dirs.append(d)
        except Exception:
            pass
    return pycache_dirs, pyc_files, empty_dirs

def apply_cleanup(pycache_dirs: List[Path], pyc_files: List[Path], empty_dirs: List[Path], apply: bool = False) -> Dict[str,int]:
    counts = {"pycache_dirs": 0, "pyc_files": 0, "pruned_dirs": 0}
    for d in pycache_dirs:
        print(" - __pycache__:", d)
        if apply:
            try:
                shutil.rmtree(str(d)); counts["pycache_dirs"] += 1
            except Exception as e:
                print("   fail:", e)
    for f in pyc_files:
        print(" - .pyc:", f)
        if apply:
            try:
                f.unlink(); counts["pyc_files"] += 1
            except Exception as e:
                print("   fail:", e)
    for d in empty_dirs:
        print(" - empty dir:", d)
        if apply:
            try:
                d.rmdir(); counts["pruned_dirs"] += 1
            except Exception as e:
                print("   fail:", e)
    return counts

# ---------------------------
# CLI
# ---------------------------
def parse_args():
    p = argparse.ArgumentParser(description="ADAAD Tree Dashboard — agent tagging + HTML export")
    p.add_argument("path", nargs="?", default=".", help="path to ADAAD root (default: current dir)")
    p.add_argument("--max-depth", type=int, default=None, help="max recursion depth")
    p.add_argument("--all", action="store_true", help="show all files (disables runtime focus)")
    p.add_argument("--optimize", action="store_true", help="find cleanup targets (dry-run)")
    p.add_argument("--apply", action="store_true", help="apply cleanup (use with care)")
    p.add_argument("--out", default="adaad_tree_dashboard.html", help="HTML output filename")
    return p.parse_args()

def main():
    args = parse_args()
    root = Path(args.path).expanduser().resolve()

    if not root.exists():
        print(C.RED + "Path not found:" + str(root) + C.END); sys.exit(2)
    exclude_dirs = DEFAULT_EXCLUDE_DIR_PATTERNS
    exclude_files = DEFAULT_EXCLUDE_FILE_PATTERNS
    focus = "all" if args.all else "runtime"

    print(C.BOLD + f"📂 ADAAD Tree for: {root}" + C.END)
    tree_root, summary = build_tree(root, args.max_depth, exclude_dirs, exclude_files, focus)
    print_tree(tree_root)
    print()
    print(C.BOLD + f"Summary: {summary['dirs']} dirs, {summary['files']} files, {summary['agents']} agents" + C.END)

    # optional optimization
    if args.optimize or args.apply:
        print("\n" + C.YELLOW + "Scanning for cleanup targets..." + C.END)
        pycache_dirs, pyc_files, empty_dirs = find_cleanup_targets(root)
        print(C.YELLOW + f"Found: {len(pycache_dirs)} __pycache__ dirs, {len(pyc_files)} .pyc files, {len(empty_dirs)} empty dirs" + C.END)
        if args.apply:
            print(C.RED + "Applying cleanup (destructive)..." + C.END)
        counts = apply_cleanup(pycache_dirs, pyc_files, empty_dirs, apply=args.apply)
        print(C.GREEN + f"Cleanup counts: {counts}" + C.END)

    # HTML export
    try:
        tree_html = node_to_html(tree_root, root)
        final_html = HTML_TEMPLATE.replace("${TREE_HTML}", tree_html).replace("{css}", BRAND_CSS)
        out_path = root / args.out
        out_path.write_text(final_html, encoding="utf-8")
        print(C.CYAN + f"HTML dashboard exported: {out_path}" + C.END)
    except Exception as e:
        print(C.RED + "Failed to export HTML: " + str(e) + C.END)
        print(traceback.format_exc())

if __name__ == "__main__":
    main()