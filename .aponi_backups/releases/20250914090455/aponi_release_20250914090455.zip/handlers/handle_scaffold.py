#!/usr/bin/env python3
from core.phonearena_core import scaffold_project
def run(name):
    return scaffold_project(name)
